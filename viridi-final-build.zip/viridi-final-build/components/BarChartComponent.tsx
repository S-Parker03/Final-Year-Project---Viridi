import React from 'react';
import { Alert, View, Text, StyleSheet, LayoutChangeEvent } from 'react-native';
import { BarChart } from 'react-native-gifted-charts';
import moment from 'moment';


interface BarChartComponentProps {
  data: number[];
  labels?: string[];  // These are ISO strings
  metric?: string;
  period?: string;
  containerWidthProp?: number;
  containerHeightProp?: number;
  metricUnit?: string;
}

// Format the label based on the period and timestamp
const formatLabel = (label: string, period?: string) => {
  if (!period) return label;
  if (period === '8 hours') {
    return moment(label).format('ha'); // 3PM
  } else if (period === '1 day') {
    return moment(label).format('ha'); // 3PM
  } else if (period === '7 days') {
    return moment(label).format('ddd'); // Mon
  } else if (period === '30 days') {
    return moment(label).format('[W]WW'); // W08 shows week of year in ISO, could be clearer...
  } else if (period === '90 days' || period === 'all time') {
    // For 90 days+ group by month.
    return moment(label).format('MMM'); //could do with a more scalable solution for all time
  }
  return label;
};

//  Aggregate the raw data into bins based on the period
//  The grouping is determined by time rather than reading count in case of missing data points
//    • "8 hours": group by the hour (each reading forms its own bin)
//    • "1 day": group by 3‑hour intervals
//    • "7 days": group by day
//    • "30 days": group by week
//    • "90 days" and "all time": group by month
const aggregateBarData = (
  data: number[],
  labels?: string[],
  period?: string
): { value: number; rawLabel: string; label: string }[] => {
  // Group readings by time‐bucket keys
  const groups: { [key: string]: { sum: number; count: number; timestamps: string[] } } = {};

  if (!labels || labels.length !== data.length) {
    data.forEach((val, index) => {
      const key = String(index);
      if (!groups[key]) {
        groups[key] = { sum: 0, count: 0, timestamps: [] };
      }
      groups[key].sum += val;
      groups[key].count++;
      groups[key].timestamps.push('');
    });
  } else {
    data.forEach((value, index) => {
      const ts = moment(labels[index]);
      let groupKey = "";
      if (period === "8 hours") {
        groupKey = ts.format("YYYY-MM-DD HH");
      } else if (period === "1 day") {
        const hourGroup = Math.floor(ts.hour() / 3) * 3;
        groupKey = ts.format("YYYY-MM-DD") + " " + hourGroup.toString().padStart(2, "0");
      } else if (period === "7 days") {
        groupKey = ts.format("YYYY-MM-DD");
      } else if (period === "30 days") {
        groupKey = ts.format("GGGG-[W]WW");
      } else if (period === "90 days" || period === "all time") {
        groupKey = ts.format("YYYY-MM");
      } else {
        groupKey = labels[index];
      }
      if (!groups[groupKey]) {
        groups[groupKey] = { sum: 0, count: 0, timestamps: [] };
      }
      groups[groupKey].sum += value;
      groups[groupKey].count++;
      groups[groupKey].timestamps.push(labels[index]);
    });
  }

  // Aggregate the data into an array of objects
  // Each object contains the average value, the representative raw label, and the formatted label
  const aggregated: { value: number; rawLabel: string; label: string }[] = [];
  for (const key in groups) {
    const group = groups[key];
    const avg = group.sum / (group.count || 1);
    // Take the middle timestamp as the representative label.
    const repTs =
      group.timestamps.length > 0
        ? group.timestamps[Math.floor(group.timestamps.length / 2)]
        : "";
    aggregated.push({
      value: avg,
      rawLabel: repTs,
      label: repTs ? formatLabel(repTs, period) : ""
    });
  }
  // Sort by the raw label, convert to Date if it's a timestamp;
  aggregated.sort((a, b) => new Date(a.rawLabel).getTime() - new Date(b.rawLabel).getTime());
  return aggregated;
};

// This component renders a bar chart using the react-native-gifted-charts library, the data and labels are provided as props
const BarChartComponent: React.FC<BarChartComponentProps> = ({data, labels, metric, period, metricUnit}) => {
  // measure the container size
  const [containerWidth, setContainerWidth] = React.useState<number>(
    0
  );
  const [containerHeight, setContainerHeight] = React.useState<number>(
    200
  );

  const aggregatedData = aggregateBarData(data, labels, period);
  const barWidth = 16;

  // set size of the chart container
  const onLayoutContainer = (event: LayoutChangeEvent) => {
    const { width, height } = event.nativeEvent.layout;
    setContainerWidth(width);
    setContainerHeight(height);

  };

  const customSpacing = aggregatedData.length > 0 ? (containerWidth - aggregatedData.length * barWidth) /  (aggregatedData.length + 1): 0;

  return (
    <View style={styles.chartContainer} onLayout={onLayoutContainer}>
      {/* Render the bar chart only if there is data and the container width is greater than 0 */}
      {aggregatedData.length > 0 && containerWidth > 0 && (
        <BarChart
          data={aggregatedData}
          barWidth={17}
          initialSpacing={20}
          spacing={customSpacing-5}
          stepHeight={containerHeight/10}
          barBorderRadius={0}
          disableScroll={true}
          frontColor={'white'}
          onPress={(item: { value: any; }) => {
            //show value of bar on press
            Alert.alert( "Bar Value:", item.value.toFixed(2));
          }}
          yAxisThickness={0}
          xAxisType={"dashed"}
          xAxisColor={"white"}
          yAxisTextStyle={{ color: "white" }}
          stepValue={Math.max(...aggregatedData.map((d) => d.value)) / 6}
          maxValue={Math.max(...aggregatedData.map((d) => d.value)) * 1.1}
          noOfSections={6}
          labelWidth={17}
          xAxisLabelTextStyle={{ color: "white", fontSize: 10 }}
        />
      )}
      {metric && (
        <Text style={styles.title}>
          {metric ? metric.charAt(0).toUpperCase() + metric.slice(1) : ""} {period && `(${period})`} {metricUnit && `(${metricUnit})`}
        </Text>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  chartContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 10,
    marginTop: 20,
    width: "100%",
    height: "100%",
    overflow: 'hidden',
    paddingBottom: 10,
  },
  title: {
    color: 'white',
    fontSize: 14,
    fontWeight: 'bold',
  },
});

export default BarChartComponent;