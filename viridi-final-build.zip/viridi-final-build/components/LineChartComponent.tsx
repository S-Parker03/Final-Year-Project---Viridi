import React from 'react';
import { useState, useEffect } from 'react';
import { View, Text, StyleSheet, LayoutChangeEvent, Dimensions } from 'react-native';
import { LineChart } from 'react-native-gifted-charts';
import moment from 'moment';

// Define the props for the LineChartComponent
interface LineChartComponentProps {
  data: number[];
  labels?: string[];
  metric?: string;
  period?: string;
  metricUnit?: string;
}

// Function to format the label based on the period
const formatLabel = (label: string, period?: string) => {
  if (!period) return label;
  if (period === '8 hours') {
    return moment(label).format('ha'); // e.g. 3:00 PM
  } else if (period === '1 day') {
    return moment(label).format('ha'); // e.g. 3PM
  } else if (period === '7 days') {
    return moment(label).format('ddd'); // e.g. Mon
  } else if (period === '30 days' || period === '90 days') {
    return moment(label).format('MMM D'); // e.g. Jan 15
  } else if (period === 'all time') {
    return moment(label).format('MMM'); // e.g. Jan
  }
  return label;
};

// Function to get 8 labels and the last label from the array of labels
const getEightLabelsAndLastLabel = (labels: string[], period?: string) => {
  if (!labels || labels.length === 0) return [];

  const step = Math.ceil(labels.length / 8);
  const selectedLabels = labels.filter((_, index) => index % step === 0 || index === labels.length - 1);

  return selectedLabels.map(label => formatLabel(label, period));
};

// This component renders a line chart using the data and labels provided as props
const LineChartComponent: React.FC<LineChartComponentProps> = ({ data, labels, metric, period, metricUnit }) => {
  const [containerWidth, setContainerWidth] = useState(150);
  const [containerHeight, setContainerHeight] = useState(100);

  const step = Math.ceil(data.length / 8);

  //Show the last data point and every nth data point
  const chartData = data.map((item, index) => ({
    value: item,
    dataPointRadius: (index % step === 0 || index === data.length - 1) ? 4 : 0,
    dataPointColor: (index % step === 0 || index === data.length - 1) ? "#FF0000" : "transparent",
  }));

  

  // Set the width and height of the container based on the layout event
  const onLayoutContainer = (event: LayoutChangeEvent) => {
    const { width, height } = event.nativeEvent.layout;
    setContainerWidth(width-20);
    setContainerHeight(height);
  };

  

  return (
    <View style={styles.chartContainer} onLayout={onLayoutContainer}>
      {containerWidth > 0 && containerHeight > 0 && chartData.length >0 && (
        <>
          <LineChart
            data={chartData}
            color="#FFFFFF"
            hideRules={false}
            disableScroll={true}
            rulesType='solid'
            hideDataPoints={false}
            height={containerHeight-75}
            width={containerWidth}
            initialSpacing={2}
            yAxisThickness={2}
            xAxisThickness={2}
            yAxisTextStyle={{ color: "white", fontSize: 10 }}
            yAxisColor={"#FFFFFF"}
            xAxisColor={"#FFFFFF"}
            spacing={(containerWidth-20) / (data.length - 1)} />
        </>
      )}
      {getEightLabelsAndLastLabel(labels || [], period).length > 0 && (
        <View style={{ width: containerWidth, marginLeft: 22, flexDirection: 'row', justifyContent: 'space-between', marginTop: 5 }}>
          {getEightLabelsAndLastLabel(labels || [], period).map((label, index) => (
            <Text key={index} style={{ color: "white", fontSize: 10 }}>{label}</Text>
          ))}
        </View>
      )}
      <Text style={styles.title}>
        {metric ? metric.charAt(0).toUpperCase() + metric.slice(1) : ""} {period && `(${period})`} {metricUnit && `(${metricUnit})`}
      </Text>
    </View>
  );
};

const styles = StyleSheet.create({
  title: {
    color: 'white',
    fontSize: 14,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  chartContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 0,
    marginTop: 5,
    width: "100%",
    height: "100%",
    overflow: 'hidden',
    marginRight: 10
  },
});

export default LineChartComponent;