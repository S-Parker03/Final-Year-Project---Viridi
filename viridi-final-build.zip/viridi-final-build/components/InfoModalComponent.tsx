import React from 'react';
import { Modal, View, Text, Pressable, StyleSheet, Linking } from 'react-native';
import { BlurView } from 'expo-blur';
import { BarChart, PieChart } from 'react-native-gifted-charts';

// Define the props for the InfoModalComponent
interface InfoModalComponentProps {
  visible: boolean;
  onClose: () => void;
  title: string;
  description: string;
  values?: number[];
}

// The InfoModalComponent is a modal that displays information about the current air quality index (AQI), temperature, or humidity.
const InfoModalComponent: React.FC<InfoModalComponentProps> = ({ visible, onClose, title, description, values }) => {

    // Helper function to get the colour for AQI levels
    // #00e400 = good(0-50), #FFFF00 = moderate(51-100), #ff7e00 = unhealthy for sensitive groups(101-150), #FF0000 = unhealthy(151-200), #99004c = very unhealthy(201-300), #7e0023 = hazardous(301+) */}
    const getAQIColour = (value: number) => {
        if (value <= 50) return '#00e400'; // Good
        else if (value <= 100) return '#FFFF00'; // Moderate
        else if (value <= 150) return '#ff7e00'; // Unhealthy for Sensitive Groups
        else if (value <= 200) return '#FF0000'; // Unhealthy
        else if (value <= 300) return '#99004c'; // Very Unhealthy
        else return '#7E0023'; // Hazardous
    }

    //Helper function to get the colour for humidity levels
    //  Very high (>80) = #FF000080, High (>60) = #ff7e0080, Comfortable (30-60) = #00e400, Low (<30) = #00ffff80 
    const getHumidityColour = (value: number) => {
        if (value < 30) return '#00ffff'; // Low
        else if (value >= 30 && value <= 60) return '#00e400'; // Comfortable
        else if (value > 60 && value <= 80) return '#ff7e00'; // High
        else return '#FF0000'; // Very High
    }

    // Pie chart data for easy comparison of AQI levels
    const pieData = [
        {value: values ? values[0] : 0, color: getAQIColour(values ? values[0] : 0), text: `${values ? values[0] : 0}`},
        {value: values ? values[1] : 0, color: getAQIColour(values ? values[1] : 0), text: `${values ? values[1] : 0}`},
        {value: values ? values[2] : 0, color: getAQIColour(values ? values[2] : 0), text: `${values ? values[2] : 0}`},
    ];

    // Data for the bar chart comparing current temperature to 2014 average temperature
    const tempData2014 = {
        //sourced from https://www.metoffice.gov.uk/binaries/content/assets/metofficegovuk/pdf/weather/learn-about/uk-past-events/state-of-uk-climate/state-of-the-uk-climate-2014-v3.pdf
        "January": 4.8,
        "February": 5.2,
        "March": 6.7,
        "April": 9.2,
        "May": 11.2,
        "June": 14.2,
        "July": 16.3,
        "August": 13.9 ,
        "September": 13.9,
        "October": 11.1,
        "November": 7.6,
        "December": 4.4,
    }

    // Function to get the bar chart data for the current temperature compared to 2014 average temperature
    const getBarData = () => {
        let now = new Date();
        const monthName = now.toLocaleString('default', { month: 'long' });
        const year = now.getFullYear();
        const barData = [];
        barData.push({value: tempData2014[monthName as keyof typeof tempData2014], label: monthName.substring(0, 3) + " 2014", frontColor: "yellow"});
        barData.push({value: values? values[0] : 0, label: monthName.substring(0, 3) + " " + year, frontColor: "#FF0000"});
        return barData;
    };

    return (
        <Modal visible={visible} transparent animationType="fade">
            <BlurView intensity={100} style={styles.fullScreenContainer}>
                        <View style={styles.modalContainer}>
                            <Text style={styles.modalTitle}>{title}</Text>
                            <Text style={styles.modalDescription}>{description}</Text>
                            {/* // Displays the pie chart and other info for AQI and bar chart and caption for temperature */}
                            {values && values.length > 0 && title === "AQI" && (
                                <>
                                    <PieChart
                                        strokeWidth={1}
                                        focusOnPress 
                                        strokeColor="#333"
                                        data={pieData}
                                        showText
                                        textColor="black"
                                        radius={75}
                                        textSize={16}
                                        
                                    />
                                    <Text style={[styles.modalDescription, { textAlign: 'center' }]}>
                                        <Text style={{color: getAQIColour(values[0])}}>PM2.5: {values[0]}</Text>
                                        {'\n'}
                                        <Text style={{color: getAQIColour(values[1])}}>PM10: {values[1]}</Text>
                                        {'\n'}
                                        <Text style={{color: getAQIColour(values[2])}}>Ozone: {values[2]}</Text>
                                    </Text>
                                    <Text style={[styles.modalDescription, { textAlign: 'center' }]}>
                                        The current AQI is {Math.max(...values)} which is 
                                        <Text style={{ color: getAQIColour(Math.max(...values)) }}>
                                            {(() => {
                                                if (values[0] <= 50) return " Good";
                                                else if (values[0] <= 100) return " Moderate";
                                                else if (values[0] <= 150) return " Unhealthy for Sensitive Groups";
                                                else if (values[0] <= 200) return " Unhealthy";
                                                else if (values[0] <= 300) return " Very Unhealthy";
                                                else return "Hazardous";
                                            })()}
                                        </Text>
                                    </Text>
                                    <Text style={[styles.modalDescription, { textAlign: 'center' }]}>
                                        The colours and hazard levels are:
                                        {'\n'}
                                        <Text style={{ color: '#00e400', fontWeight: "bold" }}>Good (0-50)</Text>
                                        {'\n'}
                                        <Text style={{ color: '#FFFF00', fontWeight: "bold" }}>Moderate (51-100)</Text>
                                        {'\n'}
                                        <Text style={{ color: '#ff7e00', fontWeight: "bold" }}>Unhealthy for Sensitive Groups (101-150)</Text>
                                        {'\n'}
                                        <Text style={{ color: '#FF0000', fontWeight: "bold" }}>Unhealthy (151-200)</Text>
                                        {'\n'}
                                        <Text style={{ color: '#99004c', fontWeight: "bold" }}>Very Unhealthy (201-300)</Text>
                                        {'\n'}
                                        <Text style={{ color: '#7E0023', fontWeight: "bold" }}>Hazardous (301+)</Text>
                                    </Text>
                                </>
                            )}
                            {values && values.length > 0 && title == "Temperature" && (
                                <>
                                    <BarChart
                                        data={getBarData()}
                                        width={125}
                                        height={150}
                                        barWidth={20}
                                        labelWidth={25}
                                        initialSpacing={17}
                                        spacing={45}
                                        xAxisColor={"white"}
                                        yAxisColor={"white"}
                                        yAxisThickness={2}
                                        xAxisThickness={2}
                                        rulesColor={"white"}
                                        yAxisTextStyle={{ color: 'white' }}
                                        xAxisLabelTextStyle={{ color: 'white' }}
                                        disableScroll={true}
                                    />
                                    <Text style={[styles.modalDescription, { textAlign: 'center' }]}>
                                        {'\n'}
                                        It is {(() => {
                                            const x = getBarData()[1].value;
                                            const y = getBarData()[0].value;
                                            const z = x - y;
                                            if (z > 0) {
                                                return `${z.toFixed(1)}°C warmer than 2014`;
                                            } else if (z < 0) {
                                                return `${Math.abs(z).toFixed(1)}°C cooler than 2014`;
                                            } else {
                                                return "the same temperature as 2014";
                                            }
                                        })()}
                                    </Text>
                                </>
                            )}
                            {values && values.length > 0 && title == "Humidity" && (
                                <Text style={[styles.modalDescription, { textAlign: 'left' }]}>
                                    The current RH is {values[0]}% which is:
                                    {'\n'}
                                    <Text style={{ color: getHumidityColour(values[0]), fontWeight: "bold"}}>
                                        {(() => {
                                            if (values[0] < 30) return "Low (<30%RH)";
                                            else if (values[0] >= 30 && values[0] <= 60) return "Comfortable (Between 30 and 60%RH)";
                                            else if (values[0] > 60 && values[0] <= 80) return "High (Between 60 and 80%RH)";
                                            else return "Very High (>80%RH)";
                                        })()}
                                    </Text>
                                    {'\n\n'}
                                    You may experience:
                                    {'\n'}
                                    {(() => {
                                        if (values[0] < 30) return "Dry skin, dry eyes, and dehydration.";
                                        else if (values[0] >= 30 && values[0] <= 60) return "Little to no negative effects.";
                                        else if (values[0] > 60 && values[0] <= 80) return "Increased sweating and discomfort in hot weather or, if its cold, a low risk of hypothermia.";
                                        else return "Excessive sweating, heat exhaustion, and heat stroke in hot weather or, if its cold, increased risk of hypothermia.";
                                    })()}
                                </Text>
                            )}
                            
                            {/* // Link to a webpage where the user can read more about the metric */}
                            <Text
                                style={[styles.modalDescription, { textDecorationLine: 'underline' }]}
                                onPress={() => {
                                    if(title === "Temperature"){
                                    Linking.openURL('https://www.climate.gov/news-features/understanding-climate/climate-change-global-temperature')
                                    }
                                    else if(title === "Humidity"){
                                    Linking.openURL('https://weather.metoffice.gov.uk/learn-about/weather/types-of-weather/humidity/effects')
                                    }
                                    else if(title === "AQI"){
                                    Linking.openURL('https://www.airnow.gov/aqi/aqi-basics/')
                                    }
                                }}
                            > 
                                Read More about {title} Here 
                            </Text>
                            <Pressable onPress={onClose} style={styles.closeButton}>
                                <Text style={styles.closeButtonText}>Close</Text>
                            </Pressable>
                        </View>
            </BlurView>
        </Modal>
    
    );
};

const styles = StyleSheet.create({
  fullScreenContainer: {
    zIndex: 1,
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContainer: {
    backgroundColor: 'rgba(113, 113, 135, 0.7)',
    padding: 20,
    borderRadius: 10,
    width: '80%',
    alignItems: 'center',
    zIndex: 100, 
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: 'white',
    marginBottom: 10,
  },
  modalDescription: {
    fontSize: 16,
    color: 'white',
    textAlign: 'left',
    marginBottom: 20,
  },
  closeButton: {
    backgroundColor: 'rgba(255,255,255,0.5)',
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 20,
  },
  closeButtonText: {
    color: 'white',
    fontWeight: 'bold',
  },
});

export default InfoModalComponent;