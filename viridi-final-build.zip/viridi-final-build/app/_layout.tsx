import { Stack } from "expo-router";
import { Text, View } from "react-native";
import { StatusBar } from "expo-status-bar";

// This is the root layout for the app. It contains the navigation stack and the status bar.
// It is used to define the overall structure of the app and to set up the navigation stack.
export default function RootLayout() {
  return <RootLayoutNav />;
}

function RootLayoutNav() {
  return (
    <Stack>
      <Stack.Screen name="(tabs)"
        options={{
          headerShown: false,
        }}
      />
    </Stack>
  );
}