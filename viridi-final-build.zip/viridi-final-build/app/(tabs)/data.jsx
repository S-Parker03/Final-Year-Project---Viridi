import { ImageBackground, StyleSheet, Text, View, FlatList, Button } from "react-native";
import { Link } from "expo-router";
import { LinearGradient } from "expo-linear-gradient";
import { BlurView } from "expo-blur";
import React, {useEffect, useState} from 'react';
import BarChartComponent from "../../components/BarChartComponent";
import LineChartComponent from "../../components/LineChartComponent";

//This screen is used to display the data from the API in a graph format
export default function DataScreen() {
    const [graphData, setGraphData] = useState({ timeStamps: [], values: [] });
    const [metric, setMetric] = useState("temperature");
    const [period, setPeriod] = useState("8 hours");
    
    //useEffect to fetch the data when the component mounts or when the metric or period changes
    useEffect(() => {
        fetchGraphData();
    }, [metric, period]);

// Fetch the metric data from the API and return the values
    //make sure to add your own API key here
    //update the channel ID to match your channel ID
    //update the field numbers to match your field number
    const fetchMetric = async (metric, start, end) => {
            let timeStamps = [];
            let values = [];
            var field;
            switch (metric) {
                case "temperature":
                    field = 2;
                    break;
                case "humidity":
                    field = 3;
                    break;
                case "PM2.5":
                    field = 7;
                    break;
                case "PM10":
                    field = 8;
                    break;
                case "O3":
                    field = 5;
                    break;
            }
            try {
                const response = await fetch("https://api.thingspeak.com/channels/<Your Channel Here>/fields/" + field + ".json?api_key=<Your Read API Key>&start="+start+"&end="+end, {
                    method: 'GET'
                });
                const data = await response.json();
                if (data.feeds && data.feeds.length > 0){
                    data.feeds.forEach(feed => {
                        if (feed[`field${field}`]){
                            values.push(parseFloat(feed[`field${field}`]));
                            timeStamps.push(feed.created_at);
                        }
                    });
                }
            }
            catch (error) {
                console.error('Error fetching AQI Data:', error);

            }
            console.log(timeStamps);
            console.log(metric + " values: " + values);
            return { timeStamps, values };

    }

    //Helper function to get relevant times for the graphs
    //Used to get the start and end times for the API call
    const getTimes = () => {
            var date = new Date();
            var EightHoursAgo = date - 1000 * 60 * 60 * 8;
            var yesterday = date - 1000 * 60 * 60 * 24 * 1;
            var SevenDaysAgo = date - 1000 * 60 * 60 * 24 * 7;
            var ThirtyDaysAgo = date - 1000 * 60 * 60 * 24 * 30;
            var NinetyDaysAgo = date - 1000 * 60 * 60 * 24 * 90;
            yesterday = new Date(yesterday);
            EightHoursAgo = new Date(EightHoursAgo);
            SevenDaysAgo = new Date(SevenDaysAgo);
            ThirtyDaysAgo = new Date(ThirtyDaysAgo);
            NinetyDaysAgo = new Date(NinetyDaysAgo);
            var dates = [date, EightHoursAgo, yesterday, SevenDaysAgo, ThirtyDaysAgo, NinetyDaysAgo];
            for(var i = 0; i < dates.length; i++){
                //format date to be YYYY-MM-DD%20HH:NN:SS
                 //2025-03-18%2016:00:50
                dates[i] = dates[i].toISOString();
                dates[i] = dates[i].slice(0, 10) + "%20" + dates[i].slice(11, 19);
            }
            return dates;
    }

    //Helper function to format the timestamps to be human readable
    //2025-04-21T02:06:09Z to 2025-04-21 02:06:09
    const formatTimeStamps = (data) => {
        var timestamps = [];
        if(!data){
            return [];
        }
        else{
            for (var i = 0; i < data.length; i++){
                var date = data[i].slice(0, 10);
                var time = data[i].slice(11, 19);
                timestamps.push(date + " " + time);
            }
            return timestamps;
        }
    }

    //Helper function to get the unit of the metric
    //Update to match your units and metrics
    const getUnit = (metric) => {
        switch(metric) {
            case "temperature":
                return "°C";
            case "humidity":
                return "RH%";
            case "PM2.5":
                return "µg/m³";
            case "PM10":
                return "µg/m³";
            case "O3":
                return "ppm";
            default:
                return "";
        }
    }

    //This function is called when the component mounts and when the metric or period changes
    //It fetches the data from the API and sets the graphData state to the data returned from the API
    //It also sets the metric and period states to the selected values and updates the graph
    //Make sure to update metric and period to match your metrics and periods
    const fetchGraphData = async () => {
            var times = getTimes();
            var now = times[0];
            var theYear2000 = "2000-01-01%2000:00:00";
            var then = theYear2000;
            var channel = 0;
            //getting right channel
            switch (metric) {
                case "temperature":
                    channel = 2;
                    break;
                case "humidity":
                    channel = 3;
                    break;
                case "PM2.5":
                    channel = 7;
                    break;
                case "PM10":
                    channel = 8;
                    break;
                case "O3":
                    channel = 5;
                    break;
            }
            //getting right period
            switch (period) {
                case "8 hours":
                    then = times[1];
                    break;
                case "1 day":
                    then = times[2];
                    break;
                case "7 days":
                    then = times[3];
                    break;
                case "30 days":
                    then = times[4];
                    break;
                case "90 days":
                    then = times[5];
                    break;
                case "all time":
                    then = theYear2000;
                    break;
            }
            console.log(then, now);
            var data = await fetchMetric(metric, then, now);
            setGraphData(data);
    }
    
    //Updates the metric state when the user selects a new metric
    const updateMetric = (newMetric) => {
        setMetric(newMetric);
    }

    //Updates the period state when the user selects a new period
    const updateTime = (newPeriod) => {
        setPeriod(newPeriod);
    }

  return (
      <>
        <ImageBackground source={require("../../assets/images/datascreen.png")} style={styles.container}>
        </ImageBackground>
        <BlurView intensity={60} tint="prominent" style={styles.graphBlur}>
            <LinearGradient
                        colors={['rgba(255,255,255,0.00)', 'rgba(255,255,255,0.20)']}
                        start={{ x: 0.2, y: 0 }}
                        end={{ x: 0.8, y: 1 }}
                        style={styles.graphGradient}
            >
                <Text style={styles.selectionText}>Select Metric: </Text>
                  <View style={styles.selectionContainer}>
                    <Button style={styles.selectionButton} title = "Temp" color={metric === "temperature" ?  "#0000FF": "#FFFFFF40"} onPress = {() => updateMetric("temperature")}></Button>
                    <Button style={styles.selectionButton} title = "Humidity" color={metric === "humidity" ?  "#0000FF": "#FFFFFF40"} onPress = {() => updateMetric("humidity")}></Button>
                    <Button style={styles.selectionButton} title = "PM2.5" color={metric === "PM2.5" ?  "#0000FF": "#FFFFFF40"} onPress = {() => updateMetric("PM2.5")}></Button>
                    <Button style={styles.selectionButton} title = "PM10" color={metric === "PM10" ?  "#0000FF": "#FFFFFF40"} onPress = {() => updateMetric("PM10")}></Button>
                    <Button style={styles.selectionButton} title = "O3" color={metric === "O3" ?  "#0000FF": "#FFFFFF40"} onPress = {() => updateMetric("O3")}></Button>
                  </View>
                <Text style={styles.selectionText}>Select Time Period: </Text>
                    <View style={styles.selectionContainer}>
                        <Button style={styles.selectionButton} title = "8Hr" color={period === "8 hours" ?  "#0000FF": "#FFFFFF40"}  onPress = {() => updateTime("8 hours")}></Button>
                        <Button style={styles.selectionButton} title = "1D" color={period === "1 day" ?  "#0000FF": "#FFFFFF40"} onPress = {() => updateTime("1 day")}></Button>
                        <Button style={styles.selectionButton} title = "7D" color={period === "7 days" ?  "#0000FF": "#FFFFFF40"} onPress = {() => updateTime("7 days")}></Button>
                        <Button style={styles.selectionButton} title = "30D" color={period === "30 days" ?  "#0000FF": "#FFFFFF40"} onPress = {() => updateTime("30 days")}></Button>
                        <Button style={styles.selectionButton} title = "90D"color={period === "90 days" ?  "#0000FF": "#FFFFFF40"} onPress = {() => updateTime("90 days")}></Button>
                        <Button style={styles.selectionButton} title = "AllTime" color={period === "all time" ?  "#0000FF": "#FFFFFF40"} onPress = {() => updateTime("all time")}></Button>
                    </View>
            </LinearGradient>
        </BlurView>
        <BlurView intensity={60} tint="prominent" style={styles.graphBlur2}>
                    <LinearGradient
                                colors={['rgba(177, 172, 219, 0.6)', 'rgba(101, 100, 148, 0.8)']}
                                start={{ x: 0.2, y: 0 }}
                                end={{ x: 0.8, y: 1 }}
                                style={styles.graphGradient}
                    >
                        <LineChartComponent data={graphData.values} labels={formatTimeStamps(graphData.timeStamps)} metric={metric} period={period} metricUnit={getUnit(metric)}/>
                    </LinearGradient>
        </BlurView>
        <BlurView intensity={60} tint="prominent" style={styles.graphBlur3}>
                    <LinearGradient
                                colors={['rgba(101, 100, 197, 0.6)', 'rgba(101, 100, 148, 0.8)']}
                                start={{ x: 0.2, y: 0 }}
                                end={{ x: 0.8, y: 1 }}
                                style={[styles.graphGradient, {height: "100%"}, {maxWidth: "100%"}, {display: "flex"}, {flexDirection: "row"}, {alignItems: "center"}, {justifyContent: "space-evenly"}]}
                    >
                        <View style={{flexDirection: "column"}}>
                            <Text style={styles.labelText}>Highest Value:  </Text>
                            <Text style={styles.dataText}>{ (graphData.values.length > 0)? Math.max(...graphData.values) + getUnit(metric) : "No data" }</Text>
                        </View>
                        <View style={{flexDirection: "column"}}>
                            <Text style={styles.labelText}>Lowest Value:  </Text>
                            <Text style={styles.dataText}>{ (graphData.values.length > 0)? Math.min(...graphData.values) + getUnit(metric) : "No data" }</Text>
                        </View>
                        <View style={{flexDirection: "column"}}>
                            <Text style={styles.labelText}>Average Value:  </Text>
                            <Text style={styles.dataText}>{ (graphData.values.length > 0)? (graphData.values.reduce((a, b) => a + b, 0) / graphData.values.length).toFixed(2) + getUnit(metric) : "No data"}</Text>
                        </View>                    
                    </LinearGradient>
        </BlurView>
        <BlurView intensity={30} tint="prominent" style={styles.graphBlur4}>
                    <LinearGradient
                                colors={['rgba(177, 172, 219, 0.6)', 'rgba(101, 100, 148, 0.8)']}
                                start={{ x: 0.2, y: 0 }}
                                end={{ x: 0.8, y: 1 }}
                                style={styles.graphGradient}
                    >
                        <BarChartComponent data={graphData.values} labels={formatTimeStamps(graphData.timeStamps)} metric={metric} period={period} metricUnit={getUnit(metric)}/>
                    </LinearGradient>
        </BlurView>


      </>
  );

}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        alignItems: "center",
        justifyContent: "center",
    },
    selectionContainer: {
        flexDirection: "row",
        flexWrap: "wrap",
        paddingHorizontal: "2%",
        width: "100%",
        paddingTop:"1%",
        paddingBottom:"1%",
        justifyContent: "space-evenly",
        alignItems: "center",
        columnGap: "1%",
        alignContent: "space-between",
        rowGap: "1%",
    },
    selectionButton: {
        width: "10%",
        margin: 10,
        padding: 10,
        borderRadius: 0,

    },
    title: {
        fontSize: 20,
        fontWeight: "bold",
    },
    graphBlur: {
        position: "absolute",
        width: "80%",
        height: "22%",
        bottom: "68%",
        left: "10%",

    },
    graphBlur2: {
        position: "absolute",
        width: "80%",
        height: "22%",
        bottom: "44%",
        left: "10%",

    },
    graphBlur3: {
        position: "absolute",
        width: "80%",
        height: "12%",
        bottom: "6%",
        left: "10%",

    },
    graphBlur4: {
        position: "absolute",
        width: "80%",
        height: "22%",
        bottom: "20%",
        left: "10%",

    },
    labelText:{
        fontSize: 15,
        marginLeft: "2%",
        marginBottom:"1%",
        marginTop: "1%",
        fontWeight: "bold",
        color: "#FFFFFF",
    },
    graphGradient: {
      flex: 1,
      justifyContent: "center",
    },
    selectionText:{
        fontSize: 20,
        marginLeft: "2%",
        marginBottom:"1%",
        marginTop: "1%",
        fontWeight: "bold",
        color: "white",
    },
    dataText:{
        fontSize: 14,
        marginLeft: "10%",
        marginBottom:"1%",
        marginTop: "1%",
        fontWeight: "bold",
        color: "#F5F5F5",
    },
});
