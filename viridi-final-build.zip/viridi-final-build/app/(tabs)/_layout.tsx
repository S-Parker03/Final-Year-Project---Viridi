// This file is used to create a custom tab navigator for the app.
// It uses the expo-router library to create a tabbed navigation interface.
import { Text, StyleSheet } from 'react-native';
import { LinearGradient } from "expo-linear-gradient";
import { BlurView } from "expo-blur";

import { Tabs, TabList, TabTrigger, TabSlot } from 'expo-router/ui';

export default function Layout() {
  return (
    <Tabs>
      <TabSlot />
      <TabList style={styles.navContainer}>
        <TabTrigger name="index" href="/" style={{ width: "50%" }}>
            <BlurView intensity={15} tint="default" style={styles.blurContainer}>
                <LinearGradient
                colors={['rgba(255,255,255,0.00)', 'rgba(255,255,255,0.10)']}
                start={{ x: 0.2, y: 0 }}
                end={{ x: 0.8, y: 1 }}
                style={styles.navButton}
                >
                    <Text style={styles.navText}>Current Environment</Text>
                </LinearGradient>
            </BlurView>
        </TabTrigger>
        <TabTrigger name="data" href="/data" style={{ width: "50%" }}>
            <BlurView intensity={15} tint="default" style={styles.blurContainer}>
                <LinearGradient
                colors={['rgba(255,255,255,0.20)', 'rgba(255,255,255,0.30)']}
                start={{ x: 0.2, y: 0 }}
                end={{ x: 0.8, y: 1 }}
                style={styles.navButton}
                >
                    <Text style={styles.navText}>Past Data</Text>
                </LinearGradient>
            </BlurView>
        </TabTrigger>
      </TabList>
    </Tabs>
  );
}

const styles = StyleSheet.create({
  navContainer: {
    position: "absolute",
    zIndex: 40,
    flex: 1,
    top: 0,
    alignItems: "center",
    width: "100%",
    height: 66,
    flexDirection: "row",
    justifyContent: "flex-start",
  },
  blurContainer: {
    width: "100%",
    height: '100%',
    overflow: 'hidden', // Keeps gradient and blur inside rounded corners
  },
  navButton: {
    height: 66,
    width: "100%",
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.5)',
    borderStyle: 'solid',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    alignItems: 'center',
    justifyContent: 'center',
    elevation: 4,
  },
  navText: {
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
    color: 'white',
  },
});