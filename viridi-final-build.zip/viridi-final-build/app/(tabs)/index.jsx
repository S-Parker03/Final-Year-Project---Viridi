import { StyleSheet, Text, View, Image, Button, Pressable } from "react-native";
import { Link } from "expo-router";
import { SafeAreaView } from "react-native-safe-area-context";
import { LinearGradient } from "expo-linear-gradient";
import React, {useEffect, useState} from 'react';
import Fontisto from '@expo/vector-icons/Fontisto';
import InfoModalComponent from "../../components/InfoModalComponent";
import moment from "moment";

// This is the main screen for the Environment tab. It displays the current temperature, humidity, and AQI values.
// It also displays a background gradient that changes based on the time of day.
export default function EnvironmentScreen() {
    const [isLoading, setLoading] = useState(true);
    const [temp, setTemp] = useState(0);
    const [humidity, setHumidity] = useState(0);
    const [AQI, setAQI] = useState("");
    const [AQIs, setAQIs] = useState([]);
    const [weatherData, setWeatherData] = useState([]);
    const [lastRefresh, setLastRefresh] = useState("Loading...");
    const [gradientColors, setGradientColors] = useState(["#4c669f", "#3b5998"]); 
    const [modalVisible, setModalVisible] = useState(false);
    const [modalMetric, setModalMetric] = useState("");
    useEffect(() => {
        getGradientColors();
        fetchWeatherData();
        getAQI();
    }, []);

    // Fetches the metric data from the API and return the values
    //Make sure to add your own API key here
    //Make sure to update the channel ID to match your channel ID
    //Make sure to update the field numbers to match your field numbers
    const fetchWeatherData = async () => {
        try {
            setLoading(true);
            setLastRefresh("Loading...");
            const response = await fetch('https://api.thingspeak.com/channels/<Add Your Channel Here>/feeds.json?api_key=<Add Your Read API Key Here>&results=1', {
                    method: 'GET'
            });
            const data = await response.json();
            setWeatherData(data);
            setTemp(parseFloat(data.feeds[0].field2));
            setHumidity(parseFloat(data.feeds[0].field3));
            setLastRefresh(formatTime(data.feeds[0].created_at));
            getAQI();


        }
        catch (error) {
            console.error('Error fetching data:', error);
            return;
        }
    }

    // Format the time string to be more readable
    const formatTime = (time) => {
        //take the last entry's timestamp as input.
        //calculate the time difference.
        //format the difference as either x minutes ago or x hours ago.
        //return the formatted string.
        var now = new Date();
        var lastTime = new Date(time);
        var difference = now.getTime() - lastTime.getTime();
        var minutes = Math.floor(difference / (1000 * 60));
        var hours = Math.floor(difference / (1000 * 60 * 60));
        if (minutes < 60){
            return minutes + " minutes ago";
        }
        else if (hours < 24){
            return hours + " hours ago";
        }
        else {
            return "A while ago";
        }
    }

    // Refresh the weather data and AQI data when the refresh button is pressed
    const refresh = async () => {
        getGradientColors();
        fetchWeatherData();
        getAQI();
    }

    // Fetch the AQI data from the API and set the state variables
    const getAQI = async () => {
        //fetch 24 hour average of PM values
        //fetch 1 and 8 hour average of O3 values
        //for each of the three
        //calculate AQI based on the value
        //return greatest value

        var Metrics = {
            "Names": ["PM25Avg", "PM10Avg", "O38HourAvg"],
            "Averages": [0,0,0],
            "AQI": [0,0,0],
        }
        var times = getTimes();
        var now = times[0];
        var eightHoursAgo = times[1];
        var oneDayAgo = times[2];
        var PM25 = await fetchMetric("PM25", oneDayAgo, now);
        var PM10 = await fetchMetric("PM10", oneDayAgo, now);
        var Ozone = await fetchMetric("Ozone", eightHoursAgo, now);
        Metrics.Averages[0] = average(PM25);
        console.log(Metrics.Averages);
        Metrics.Averages[1] = average(PM10);
        console.log(Metrics.Averages);
        Metrics.Averages[2] = average(Ozone);
        console.log(Metrics.Averages);
        for (var i = 0; i < Metrics.Names.length; i++){
            Metrics.AQI[i] = calcAQI(Metrics.Names[i], Metrics.Averages[i]);
        }
        console.log("AQIs: " + Metrics.AQI);
        setAQIs(Metrics.AQI);
        if(Math.max(...Metrics.AQI) > 0){
             setAQI(Math.max(...Metrics.AQI).toString());
        }
        else{
            setAQI("No data from past 8 hours");
        }
        setLoading(false);
    }

    // Calculate the AQI based on the metric and value
    const calcAQI = (metric, value) => {
        //compare against breakpoint values
        //calculate AQI
        //round to nearest integer
        //return AQI
        //if no data then return N/A
        var breakpoints = {
          "PM25Avg": [[0.0,9.0], [9.1,35.4], [35.5,55.4], [55.5,125.4], [125.5,225.4]],
          "PM10Avg": [[0,54], [55,154], [155,254], [255,354], [355,424]],
          "O38HourAvg": [[0,54],[55,70], [71,85], [86,105], [106,200]],
        }
        var AQIBreakpoints = [[0,50], [51,100], [101,150], [151,200], [201,300]];
        var metricBreakpoints = [];
        //calculate by using formula I = (Ihi - Ilo)/(BPhi - BPlo) * (Cp - BPlo) + Ilo
        //step 1 is to select metric breakpoints
        switch (metric) {
            case "PM25Avg":
                metricBreakpoints = breakpoints.PM25Avg;
                break;
            case "PM10Avg":
                metricBreakpoints = breakpoints.PM10Avg;
                break;
            case "O38HourAvg":
                metricBreakpoints = breakpoints.O38HourAvg;
                break;
        }
      //step 2 find which pair of breakpoints the value is in
        for (var i = 0; i < metricBreakpoints.length; i++){
            if (value >= metricBreakpoints[i][0] && value <= metricBreakpoints[i][1]){
                var BPlo = metricBreakpoints[i][0];
                var BPhi = metricBreakpoints[i][1];
                var Ilo = AQIBreakpoints[i][0];
                var Ihi = AQIBreakpoints[i][1];
                return(Math.round((Ihi - Ilo)/(BPhi - BPlo) * (value - BPlo) + Ilo));
            }
        }
        //if no result within breakpoints then return 301, which means hazardous environment
        return(301);
    }

    //Fetch the metric data from the API and return the values
    //make sure to add your own API key here
    //update the channel ID to match your channel ID
    //update the field numbers to match your field number
    const fetchMetric = async (metric, start, end) => {

        let values = [];
        var field;
        switch (metric) {
            //update this to match your channel fields
            case "PM25":
                field = 7;
                break;
            case "PM10":
                field = 8;
                break;
            case "Ozone":
                field = 5;
                break;
        }
        try {
            setLoading(true);
            const response = await fetch("https://api.thingspeak.com/channels/<Insert Your Channel Here>/fields/" + field + ".json?api_key=<Add Your API Key Here>&start="+start+"&end="+end, {
                method: 'GET'
            });
            const data = await response.json();
            console.log(data);
            if (data.feeds && data.feeds.length > 0){
                data.feeds.forEach(feed => {
                    if (feed[`field${field}`]){
                        values.push(parseFloat(feed[`field${field}`]));
                    }
                });
            }
        }
        catch (error) {
            console.error('Error fetching AQI Data:', error);

        }
        return values;
    }

    // Get the times for the last 8 hours and yesterday
    const getTimes = () => {
        var date = new Date();
        var EightHoursAgo = date - 1000 * 60 * 60 * 8;
        var yesterday = date - 1000 * 60 * 60 * 24 * 1;
        yesterday = new Date(yesterday);
        EightHoursAgo = new Date(EightHoursAgo);
        var dates = [date, EightHoursAgo, yesterday];
        for(var i = 0; i < dates.length; i++){
            //format date to be YYYY-MM-DD%20HH:NN:SS
             //2025-03-18%2016:00:50
            dates[i] = dates[i].toISOString();
            dates[i] = dates[i].slice(0, 10) + "%20" + dates[i].slice(11, 19);
        }
        return dates;
    }

    // Calculate the average of an array of numbers
    const average = (numbers) => {
        if (numbers.length === 0) {
            return 0;
        }
        const sum = numbers.reduce((acc, num) => acc + num, 0);
        return sum / numbers.length;
    }

    // Show the modal with the selected metric
    const showModal = (metric) => {
        setModalMetric(metric);
        setModalVisible(true);
    }

    // A helper to interpolate between two hex colours
    function interpolateColor(color1, color2, factor) {
    // format: "#RRGGBB"
        const hex = (color) => color.replace("#", "");
        const r1 = parseInt(hex(color1).substr(0, 2), 16);
        const g1 = parseInt(hex(color1).substr(2, 2), 16);
        const b1 = parseInt(hex(color1).substr(4, 2), 16);
        const r2 = parseInt(hex(color2).substr(0, 2), 16);
        const g2 = parseInt(hex(color2).substr(2, 2), 16);
        const b2 = parseInt(hex(color2).substr(4, 2), 16);
        const r = Math.round(r1 + factor * (r2 - r1));
        const g = Math.round(g1 + factor * (g2 - g1));
        const b = Math.round(b1 + factor * (b2 - b1));
        const toHex = (n) => ("0" + n.toString(16)).slice(-2);
        return `#${toHex(r)}${toHex(g)}${toHex(b)}`;
    }
  
    // calc gradient colours based on current hour
    function getGradientColors() {
        const hour = new Date().getHours();
        let bottom, top;
        if (hour >= 0 && hour < 6) {
        // Transition from Night to Sunrise
        const factor = (hour - 0) / 6;
        bottom = interpolateColor("#043688", "#AE00A5", factor);
        top = interpolateColor("#043688", "#629DFC", factor);
        } else if (hour >= 6 && hour < 12) {
        // Transition from Sunrise to Midday
        const factor = (hour - 6) / 6;
        bottom = interpolateColor("#AE00A5", "#629DFC", factor);
        top = "#629DFC"; // solid midday on right
        } else if (hour >= 12 && hour < 18) {
        // Transition from Midday to Sunset
        const factor = (hour - 12) / 6;
        bottom = interpolateColor("#629DFC", "#AE00A5", factor);
        top = "#629DFC";
        } else {
        // Transition from Sunset to Night (18 to 24)
        const factor = (hour - 18) / 6;
        bottom = interpolateColor("#AE00A5", "#043688", factor);
        top = interpolateColor("#629DFC", "#043688", factor);
        }
        setGradientColors([top, bottom]);
    }

    return (
        <SafeAreaView style={styles.container}> 
            {/* //variable background color based on time of day   */}
            {/* midday coloursgradient #629DFC to #629DFC */}
            {/* sunset/ sunrise gradient #AE00A5 to #629DFC */}
            {/* night gradient #043688 to #043688 */}
            <LinearGradient
                colors={gradientColors}
                style={StyleSheet.absoluteFill}
            />
            <Image
                source={require("../../assets/images/Landscape.png")}
                style={styles.landscape}
                resizeMode="cover"
            />
            <Image
                source={require("../../assets/images/Chicken.jpg")}
                style={styles.chicken}
                resizeMode="contain"
            />

            <Image
                source={require("../../assets/images/Sun.png")}
                style={styles.sun}
            />
            <View style={styles.refreshButtonContainer}>
                <Fontisto.Button id="refresh-button" backgroundColor="#FFFFFF00" name="cloud-refresh" color="white" style={styles.refreshButton} onPress = {refresh}>
                    <Text style={styles.refreshButtonText}>Last Entry: {lastRefresh} </Text>
                </Fontisto.Button>
            </View>

            {/* // Metric buttons, show modal on press and vary color based on value */}
            {/* Very high >25 = #FF000080, very cold <10 = #0000ff80, comfortable = #00ff0080*/}
            <View style={styles.tempButtonContainer}>
                    <Pressable id="temp-button" style ={[styles.metricButton, {backgroundColor: temp > 25 ? "#FF000080" : temp < 10 ? "#0000ff80" : "#00ff0080"}]} onPress = {() =>showModal("Temperature")}>
                        <Text id="temp-text" style={styles.buttonText}>Temperature: </Text>
                        <Text id="temp-text" style={styles.buttonText}>{temp}°C</Text>
                    </Pressable>
            </View>
            {/* Very high (>80) = #FF000080, High (>60) = #ff7e0080, Comfortable (30-60) = #00e400, Low (<30) = #00ffff80 */}
            <View style={styles.humidityButtonContainer}>
                    <Pressable id="hum-button" style={[styles.metricButton, {backgroundColor: humidity > 80 ? "#FF000080" : humidity < 30 ? "#00ffff80" : humidity > 60 ? "#ff7e0080" : "#00e40080"}]} onPress = {() =>showModal("Humidity")}>
                        <Text id = "hum-text" style={styles.buttonText}>Humidity: </Text>
                        <Text id = "hum-text" style={styles.buttonText}>{humidity}%</Text>
                    </Pressable>
            </View>
            <View style={styles.AQIButtonContainer}>
                {/* //style based on EPA AQI guidelines, following the color scheme
                // #00e400 = good(0-50), #FFFF00 = moderate(51-100), #ff7e00 = unhealthy for sensitive groups(101-150), #FF0000 = unhealthy(151-200), #99004c = very unhealthy(201-300), #7e0023 = hazardous(301+) */}
                <Pressable id="AQI-button" style={[styles.metricButton, {width:100}, {backgroundColor: AQI > 300 ? "#7e002380" : AQI > 200 ? "#99004c80" : AQI > 150 ? "#FF000080" : AQI > 100 ? "#ff7e0080" : AQI > 50 ? "#FFFF0080" : "#00e40080"}]} onPress = {() =>showModal("AQI")}>
                    <Text id = "AQI-text" style={styles.buttonText}>AQI:</Text>
                    <Text id = "AQI-text" style={styles.buttonText}>{AQI}</Text>
                </Pressable>
            </View>
            {modalVisible && (
                <InfoModalComponent 
                visible={modalVisible} 
                onClose={() => setModalVisible(false)}
                title={modalMetric}
                description={
                    (() => {
                        if (modalMetric === "Temperature") {
                            return "The temperature shown here is that of your ambient environment. Temperature is an important environmental factor as it affects the weather and has effects on humans plants and animals. Climate change is causing global temperatures to rise, which will lead to more extreme weather events and changes in ecosystems. Below is a comparison between the current temperature and the average UK temperature this month in 2014: \n";
                        } else if (modalMetric === "Humidity") {
                            return "Relative Humidity (RH) is the most common measure of humidity. It measures how close the air is to being saturated (i.e. 100% RH means the air is holding as much water as it can).\n\nWhen it's warm air with very high RH is uncomfortable as the saturated air affects our body's cooling mechanism stopping us from effectively evaporating sweat. \n\nWhen its colder air with very high RH can make us feel cooler because there is more water vapour close to our skin.";
                        } else if (modalMetric === "AQI") {
                            return "The Air Quality Index (AQI) is a measure of air quality that indicates how clean or polluted the air is. The AQI values here are on a scale from 0 to 500, with higher values indicating worse air quality. A breakdown of the AQI values for different pollutants is shown below:\n\n";
                        } else {
                            return "Error, please close and try again.";
                        }
                    })()
                }
                values={
                    (() => {
                        if (modalMetric === "AQI") {
                            return AQIs;
                        }
                        else if (modalMetric === "Temperature") {
                            return [temp];
                        } else if (modalMetric === "Humidity") {
                            return [humidity];
                        } else {
                            return "Error, please close and try again.";
                        }
                    })()
                }
                />
            )}
        </SafeAreaView>
    );

}

const styles = StyleSheet.create({
    container: {
        flex: 1,
    },
    buttonText: {
        fontSize: 20,
        fontWeight: "bold",
        color: "white",
        textAlign: "center",
        textAlignVertical: 'center',
        flex: 2,
        justifySelf: "center",
        alignSelf: "center",
    },
    tempButtonContainer: {
        zIndex:30,
        position: "absolute",
        top: "60%",
        left: "50%",
        transform: [{ translateX: -125 }, { translateY: -400 }],
        width: "fit-content",
        height: "fit-content",
    },
    humidityButtonContainer: {
        zIndex:30,
        position: "absolute",
        top: "120%",
        left: "80%",
        transform: [{ translateX: -125 }, { translateY: -400 }],
        width: "fit-content",
        height: "fit-content",
    },
    AQIButtonContainer: {
        zIndex:30,
        position: "absolute",
        top: "40%",
        left: "10%",
        width: "fit-content",
        height: "fit-content",
    },
    landscape: {
        zIndex: 10,
        position: "absolute",
        bottom: -50,
        left: 0,
        right: 0,
        aspectRatio: 10/5.9,
    },
    sun: {
        zIndex: 5,
        position: "absolute",
        top: "50%",
        left: "50%",
        transform: [{ translateX: -125 }, { translateY: -400 }],
        width: 250,
        aspectRatio: 1,
    },
    refreshButtonContainer: {
        marginTop: "15%",
        flexDirection: "row",
        justifyContent: "center",
        alignItems: "center",
        zIndex:15,
        position: "absolute",
        left: "0%",
    },
    refreshButtonText: {
        textDecorationLine: "underline",
        color: "white",
        fontSize: 16,
        fontWeight: "bold",
    },
    metricButton: {
        display: "flex",
        flexDirection: "column",
        alignContent: "center",
        justifyContent: "center",
        alignItems: "center",
        width: "fit-content",
        padding: 10,
        height: 100,
        borderRadius: 10,
    },
    chicken: {
        zIndex: 200,
        position: "absolute",
        top: "40%",
        left: "72%",
        width: 50,
        height: 50,
    }
});
